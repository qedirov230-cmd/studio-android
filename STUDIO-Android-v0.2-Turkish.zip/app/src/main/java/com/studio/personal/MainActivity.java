package com.studio.personal;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private LinearLayout root;
    private ImageView preview;
    private TextView status;
    private Uri selectedImage;
    private EditText prompt;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private TextView txt(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void space(int h) { Space s = new Space(this); root.addView(s, new LinearLayout.LayoutParams(1, dp(h))); }
    private Button btn(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(14); b.setBackground(bg(Color.rgb(112,73,202), 16, Color.rgb(161,119,255)));
        return b;
    }
    private void tool(String title, String sub) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(13), dp(14), dp(13));
        c.setBackground(bg(Color.rgb(30,27,47), 16, Color.rgb(65,53,94)));
        c.addView(txt(title, 15, Color.WHITE, true));
        TextView d = txt(sub, 12, Color.rgb(180,171,205), false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(4);
        c.addView(d, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(9);
        root.addView(c, lp);
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(15,12,24));
        getWindow().setNavigationBarColor(Color.rgb(15,12,24));
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(Color.rgb(15,12,24));
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(19), dp(22), dp(19), dp(28)); scroll.addView(root); setContentView(scroll);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        brand.addView(txt("STUDIO", 30, Color.WHITE, true));
        brand.addView(txt("PERSONAL AI PHOTO LAB", 10, Color.rgb(183,153,255), true));
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView tag = txt("PRIVATE", 10, Color.rgb(218,201,255), true);
        tag.setPadding(dp(11), dp(7), dp(11), dp(7)); tag.setBackground(bg(Color.rgb(48,34,75), 20, Color.rgb(112,73,202)));
        top.addView(tag); root.addView(top); space(24);

        root.addView(txt("Fotoğrafını yeniden tasarla", 22, Color.WHITE, true)); space(5);
        root.addView(txt("Kıyafet • Poz • Arka plan • AI düzenleme", 13, Color.rgb(178,169,198), false)); space(17);

        LinearLayout frame = new LinearLayout(this); frame.setOrientation(LinearLayout.VERTICAL);
        frame.setPadding(dp(10), dp(10), dp(10), dp(10)); frame.setBackground(bg(Color.rgb(28,24,43), 20, Color.rgb(78,58,117)));
        preview = new ImageView(this); preview.setAdjustViewBounds(true); preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(preview, new LinearLayout.LayoutParams(-1, dp(225)));
        TextView placeholder = txt("Fotoğraf seçilmedi", 13, Color.rgb(190,181,208), false);
        placeholder.setGravity(Gravity.CENTER); LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(35)); frame.addView(placeholder, hp);
        root.addView(frame); space(13);

        Button choose = btn("＋  Galeriden fotoğraf seç");
        choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Fotoğraf seç"), 100);
        });
        root.addView(choose, new LinearLayout.LayoutParams(-1, dp(52))); space(20);

        root.addView(txt("DÜZENLEME ARAÇLARI", 10, Color.rgb(183,153,255), true)); space(10);
        tool("Kıyafet değiştir", "Günlük, klasik, abiye, mayo, bikini ve iç giyim stilleri");
        tool("Poz değiştir", "Ayakta, oturarak, farklı kamera açıları ve referans poz");
        tool("Arka planı değiştir", "Stüdyo, ev, otel, havuz, sahil ve dış mekân");
        tool("Metinle düzenle", "İstediğin değişikliği kendi cümlelerinle tarif et");
        space(8);

        prompt = new EditText(this); prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(Color.rgb(145,133,166));
        prompt.setHint("Örn.: Siyah şık elbise, havuz kenarında gün batımı...");
        prompt.setTextSize(14); prompt.setPadding(dp(14), dp(12), dp(14), dp(12));
        prompt.setMinLines(3); prompt.setGravity(Gravity.TOP);
        prompt.setBackground(bg(Color.rgb(29,25,44), 15, Color.rgb(78,58,117)));
        root.addView(prompt, new LinearLayout.LayoutParams(-1, dp(105))); space(12);

        Button run = btn("AI İLE DÜZENLE");
        run.setOnClickListener(v -> {
            String message;
            if (selectedImage == null) message = "Önce galeriden bir fotoğraf seç.";
            else message = "Fotoğraf seçildi. Bu sürüm arayüz prototipidir; AI üretim motoru henüz bağlanmadı. Sonraki aşamada bulut AI servisini entegre edeceğiz.";
            new android.app.AlertDialog.Builder(this).setTitle("STUDIO").setMessage(message).setPositiveButton("Tamam", null).show();
        });
        root.addView(run, new LinearLayout.LayoutParams(-1, dp(54))); space(12);

        status = txt("Sürüm 0.2 • Maksimum kalite hedefi • AI bağlantısı bekleniyor", 10, Color.rgb(145,133,166), false);
        status.setGravity(Gravity.CENTER); root.addView(status);
        space(8);
        TextView note = txt("Not: Üretim kalitesi ve kullanım kotası, bağlanacak AI modeline ve sunucu planına bağlıdır.", 10, Color.rgb(125,116,145), false);
        note.setGravity(Gravity.CENTER); root.addView(note);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            selectedImage = data.getData();
            try { preview.setImageURI(selectedImage); status.setText("Fotoğraf seçildi • AI motoru henüz bağlanmadı"); }
            catch (Exception e) { status.setText("Fotoğraf açılamadı. Başka bir fotoğraf seç."); }
        }
    }
}
