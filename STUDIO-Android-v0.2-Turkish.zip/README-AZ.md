# STUDIO — Android başlangıç projesi

**Sürüm:** 0.2.0  
**Arayüz:** Türkçe, siyah-mor futuristik tema  
**Hedef cihaz:** Android / Honor X9c

## Bu sürümde
- STUDIO marka ve ana ekran tasarımı
- Galeriden fotoğraf seçme ve önizleme
- Kıyafet, poz, arka plan ve metinle düzenleme bölümleri
- APK üretmek için GitHub Actions iş akışı

## Önemli durum
Bu sürüm çalışan bir Android arayüz prototipidir; AI fotoğraf üretim motoru henüz entegre değildir. Ekrandaki düzenleme seçenekleri şu anda arayüz taslağıdır. Gerçek kıyafet/poz/arka plan düzenlemesi için bir model sunucusu veya uygun bir AI API bağlantısı ve güvenli backend gerekir. API anahtarları APK içine gömülmemelidir.

## APK oluşturma
1. ZIP dosyasını açın.
2. İçindeki proje dosyalarını GitHub'da yeni bir depoya yükleyin.
3. Depoda **Actions** sekmesini açın.
4. **Build STUDIO APK** iş akışını çalıştırın.
5. İşlem tamamlanınca `STUDIO-debug-apk` artifact'ını indirin.
6. Artifact ZIP'ini açıp `app-debug.apk` dosyasını Android telefona kurun.

## Teknik
- Native Android (Java)
- Minimum Android API 26
- Compile/Target SDK 35
- JDK 17 / Gradle 8.9
