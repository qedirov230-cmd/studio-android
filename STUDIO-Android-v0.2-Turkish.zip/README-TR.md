# STUDIO — Android proje paketi

Arayüz sürümü: 0.2.0  
Dil: Türkçe  
Tema: Siyah / mor futuristik  
Hedef cihaz: Android (Honor X9c dahil)

## Bu sürümde
- STUDIO uygulama adı ve koyu mor arayüz
- Galeriden fotoğraf seçme ve önizleme
- Kıyafet, poz, arka plan ve metinle düzenleme bölümleri
- Mayo, bikini ve iç giyim gibi moda kategorileri için arayüz metinleri
- GitHub Actions ile debug APK derleme iş akışı

## Önemli durum
Bu paket henüz çalışan bir AI fotoğraf üretim motoru içermez. “AI ile düzenle” butonu şimdilik prototip durumunu açıkça bildirir. Gerçek düzenleme için ayrıca bir model servisi / GPU backend entegrasyonu gerekir. Ücretsiz bulut servislerinin kota, sıra ve kullanım koşulları vardır; sınırsız ücretsiz kullanım garanti edilemez.

## APK oluşturma
1. ZIP dosyasını açın.
2. İçindeki proje dosyalarını yeni bir GitHub repository'sine yükleyin.
3. GitHub'da Actions bölümünü açın.
4. “Build STUDIO APK” workflow'unu çalıştırın.
5. Build bitince `STUDIO-debug-apk` artifact'ını indirin.
6. Artifact ZIP'ini açıp `app-debug.apk` dosyasını Android telefona kurun.

Bu ilk APK prototipidir; sonraki geliştirme aşaması AI backend bağlantısıdır.
